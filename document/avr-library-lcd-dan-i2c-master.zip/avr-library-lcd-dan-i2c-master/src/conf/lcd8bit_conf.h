#ifndef _LCD8BIT_CONF_
#define _LCD8BIT_CONF_

#define LCD_DATA_DDR            DDRD
#define LCD_DATA_PORT           PORTD
#define LCD_DATA_PIN            PIND

#define LCD_CONT_DDR            DDRC
#define LCD_CONT_PORT           PORTC
#define LCD_CONT_RS             5
#define LCD_CONT_RW             6
#define LCD_CONT_EN             7

#endif
